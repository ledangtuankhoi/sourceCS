﻿namespace _18607077_ledangtuankhoi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNgườiDùngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchThànhPhốToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchChiTiếtHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcThànhPhốToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoEllipsis = true;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(208, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "quản lý bán hàng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(544, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "sinh viên: 18607077";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.xemDanhSáchToolStripMenuItem,
            this.xemDanhMụcToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(675, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýHệThốngToolStripMenuItem,
            this.quảnLýNgườiDùngToolStripMenuItem,
            this.đăngNhậpToolStripMenuItem,
            this.đổiMậtKhẩuToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.hệThốngToolStripMenuItem.Text = "hệ thống";
            // 
            // quảnLýHệThốngToolStripMenuItem
            // 
            this.quảnLýHệThốngToolStripMenuItem.Name = "quảnLýHệThốngToolStripMenuItem";
            this.quảnLýHệThốngToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.quảnLýHệThốngToolStripMenuItem.Text = "quản lý hệ thống";
            this.quảnLýHệThốngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHệThốngToolStripMenuItem_Click);
            // 
            // quảnLýNgườiDùngToolStripMenuItem
            // 
            this.quảnLýNgườiDùngToolStripMenuItem.Name = "quảnLýNgườiDùngToolStripMenuItem";
            this.quảnLýNgườiDùngToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.quảnLýNgườiDùngToolStripMenuItem.Text = "quản lý người dùng";
            // 
            // đăngNhậpToolStripMenuItem
            // 
            this.đăngNhậpToolStripMenuItem.Name = "đăngNhậpToolStripMenuItem";
            this.đăngNhậpToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.đăngNhậpToolStripMenuItem.Text = "đăng nhập ";
            this.đăngNhậpToolStripMenuItem.Click += new System.EventHandler(this.đăngNhậpToolStripMenuItem_Click);
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            this.đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            this.đổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.đổiMậtKhẩuToolStripMenuItem.Text = "đổi mật khẩu";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.thoátToolStripMenuItem.Text = "thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // xemDanhSáchToolStripMenuItem
            // 
            this.xemDanhSáchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhSáchThànhPhốToolStripMenuItem,
            this.danhSáchToolStripMenuItem,
            this.danhSáchSảnPhẩmToolStripMenuItem,
            this.danhSáchToolStripMenuItem1,
            this.danhSáchToolStripMenuItem2,
            this.danhSáchChiTiếtHóaĐơnToolStripMenuItem});
            this.xemDanhSáchToolStripMenuItem.Name = "xemDanhSáchToolStripMenuItem";
            this.xemDanhSáchToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.xemDanhSáchToolStripMenuItem.Text = "xem danh sách";
            // 
            // danhSáchThànhPhốToolStripMenuItem
            // 
            this.danhSáchThànhPhốToolStripMenuItem.Name = "danhSáchThànhPhốToolStripMenuItem";
            this.danhSáchThànhPhốToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.danhSáchThànhPhốToolStripMenuItem.Text = "danh sách thành phố";
            this.danhSáchThànhPhốToolStripMenuItem.Click += new System.EventHandler(this.danhSáchThànhPhốToolStripMenuItem_Click);
            // 
            // danhSáchToolStripMenuItem
            // 
            this.danhSáchToolStripMenuItem.Name = "danhSáchToolStripMenuItem";
            this.danhSáchToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.danhSáchToolStripMenuItem.Text = "danh sách khách hàng";
            this.danhSáchToolStripMenuItem.Click += new System.EventHandler(this.danhSáchToolStripMenuItem_Click);
            // 
            // danhSáchSảnPhẩmToolStripMenuItem
            // 
            this.danhSáchSảnPhẩmToolStripMenuItem.Name = "danhSáchSảnPhẩmToolStripMenuItem";
            this.danhSáchSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.danhSáchSảnPhẩmToolStripMenuItem.Text = "danh sách sản phẩm";
            this.danhSáchSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.danhSáchSảnPhẩmToolStripMenuItem_Click);
            // 
            // danhSáchToolStripMenuItem1
            // 
            this.danhSáchToolStripMenuItem1.Name = "danhSáchToolStripMenuItem1";
            this.danhSáchToolStripMenuItem1.Size = new System.Drawing.Size(214, 22);
            this.danhSáchToolStripMenuItem1.Text = "danh sách nhân viên  ";
            this.danhSáchToolStripMenuItem1.Click += new System.EventHandler(this.danhSáchToolStripMenuItem1_Click);
            // 
            // danhSáchToolStripMenuItem2
            // 
            this.danhSáchToolStripMenuItem2.Name = "danhSáchToolStripMenuItem2";
            this.danhSáchToolStripMenuItem2.Size = new System.Drawing.Size(214, 22);
            this.danhSáchToolStripMenuItem2.Text = "danh sách hóa đơn";
            this.danhSáchToolStripMenuItem2.Click += new System.EventHandler(this.danhSáchToolStripMenuItem2_Click);
            // 
            // danhSáchChiTiếtHóaĐơnToolStripMenuItem
            // 
            this.danhSáchChiTiếtHóaĐơnToolStripMenuItem.Name = "danhSáchChiTiếtHóaĐơnToolStripMenuItem";
            this.danhSáchChiTiếtHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.danhSáchChiTiếtHóaĐơnToolStripMenuItem.Text = "danh sách chi tiết hóa đơn";
            this.danhSáchChiTiếtHóaĐơnToolStripMenuItem.Click += new System.EventHandler(this.danhSáchChiTiếtHóaĐơnToolStripMenuItem_Click);
            // 
            // xemDanhMụcToolStripMenuItem
            // 
            this.xemDanhMụcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhMụcThànhPhốToolStripMenuItem,
            this.danhMụcKháchHàngToolStripMenuItem,
            this.danhMụcSảnPhẩmToolStripMenuItem,
            this.danhMụcToolStripMenuItem});
            this.xemDanhMụcToolStripMenuItem.Name = "xemDanhMụcToolStripMenuItem";
            this.xemDanhMụcToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.xemDanhMụcToolStripMenuItem.Text = "xem danh mục";
            // 
            // danhMụcThànhPhốToolStripMenuItem
            // 
            this.danhMụcThànhPhốToolStripMenuItem.Name = "danhMụcThànhPhốToolStripMenuItem";
            this.danhMụcThànhPhốToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.danhMụcThànhPhốToolStripMenuItem.Text = "danh mục thành phố";
            this.danhMụcThànhPhốToolStripMenuItem.Click += new System.EventHandler(this.danhMụcThànhPhốToolStripMenuItem_Click);
            // 
            // danhMụcKháchHàngToolStripMenuItem
            // 
            this.danhMụcKháchHàngToolStripMenuItem.Name = "danhMụcKháchHàngToolStripMenuItem";
            this.danhMụcKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.danhMụcKháchHàngToolStripMenuItem.Text = "danh mục khách hàng";
            this.danhMụcKháchHàngToolStripMenuItem.Click += new System.EventHandler(this.danhMụcKháchHàngToolStripMenuItem_Click);
            // 
            // danhMụcSảnPhẩmToolStripMenuItem
            // 
            this.danhMụcSảnPhẩmToolStripMenuItem.Name = "danhMụcSảnPhẩmToolStripMenuItem";
            this.danhMụcSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.danhMụcSảnPhẩmToolStripMenuItem.Text = "danh mục sản phẩm";
            // 
            // danhMụcToolStripMenuItem
            // 
            this.danhMụcToolStripMenuItem.Name = "danhMụcToolStripMenuItem";
            this.danhMụcToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.danhMụcToolStripMenuItem.Text = "danh mục ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(47, 90);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 290);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Màn hình chính";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNgườiDùngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemDanhSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchThànhPhốToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhSáchToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem danhSáchChiTiếtHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemDanhMụcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcThànhPhốToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcKháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcToolStripMenuItem;
        private System.Windows.Forms.Button button1;
    }
}

